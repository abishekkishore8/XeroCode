import React from 'react'
import {BrowserRouter as Router,Routes,Route} from "react-router-dom"

import Home  from '../pages/Home'
import Login from '../pages/Login'
import SignUp from '../pages/SignUp'
import Page5 from '../pages/Page5'

const Navigation = () => {
  return (
    <Router>
    
        <Routes>
            <Route path='/' element={<Home/>} />
            <Route path='/login' element={<Login/>} />
            <Route path='/signup' element={<SignUp/>} />
            <Route path='/page5' element={<Page5/>} />

            {/* <Route path='/error' element={<NotFound/>} />
            <Route path='*' element={<Navigate to="/error" />}  />
            <Route path='/bmi' element={<BMICalculator />}  /> */}
        </Routes>
        
    </Router>
  )
}

export default Navigation;
